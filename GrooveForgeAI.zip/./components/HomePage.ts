import { LitElement, html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import './Branding';

@customElement('home-page')
export class HomePage extends LitElement {
  @property({ type: Boolean }) showMainApp = false;

  static styles = css`
    :host {
      display: block;
      min-height: 100vh;
      background: radial-gradient(1200px 600px at 20% 0%, rgba(0,255,136,0.08), transparent),
                  radial-gradient(1200px 600px at 80% 100%, rgba(0,255,136,0.08), transparent),
                  var(--bg);
      font-family: 'SF Mono', Monaco, 'Cascadia Code', 'Roboto Mono', Consolas, 'Courier New', monospace;
      color: var(--text);
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
      text-align: center;
    }

    .hero {
      margin: 4rem 0;
      animation: fadeIn 1s ease-out;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .logo {
      font-size: 4rem;
      font-weight: bold;
      margin-bottom: 1rem;
    }

    @keyframes gradient {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    .tagline {
      font-size: 1.5rem;
      margin-bottom: 2rem;
      opacity: 0.9;
    }

    .description {
      font-size: 1.1rem;
      line-height: 1.6;
      max-width: 800px;
      margin: 0 auto 3rem;
      opacity: 0.8;
    }

    .features {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 2rem;
      margin: 3rem 0;
    }

    .feature {
      background: rgba(255, 255, 255, 0.05);
      padding: 2rem;
      border-radius: 15px;
      backdrop-filter: blur(10px);
      border: 1px solid var(--border);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      animation: fadeInUp 0.6s ease forwards;
      opacity: 0;
      transform: translateY(30px);
    }

    .feature:nth-child(1) { animation-delay: 0.1s; }
    .feature:nth-child(2) { animation-delay: 0.2s; }
    .feature:nth-child(3) { animation-delay: 0.3s; }

    .feature:hover {
      transform: translateY(-5px);
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
    }

    @keyframes fadeInUp {
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .feature-icon {
      font-size: 3rem;
      margin-bottom: 1rem;
    }

    .feature-title {
      font-size: 1.3rem;
      font-weight: bold;
      margin-bottom: 1rem;
    }

    .feature-description {
      opacity: 0.8;
      line-height: 1.5;
    }

    .cta-button {
      background: linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
      color: #000;
      border: none;
      padding: 1rem 3rem;
      font-size: 1.2rem;
      font-weight: bold;
      border-radius: 50px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
      margin: 2rem 0;
    }

    .cta-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
    }

    .cta-button:active {
      transform: translateY(0);
    }

    .footer {
      margin-top: 4rem;
      opacity: 0.7;
      font-size: 0.9rem;
    }

    .tech-stack {
      display: flex;
      justify-content: center;
      gap: 2rem;
      margin: 2rem 0;
      flex-wrap: wrap;
    }

    .tech-item {
      background: rgba(255, 255, 255, 0.1);
      padding: 0.5rem 1rem;
      border-radius: 20px;
      font-size: 0.9rem;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    @media (max-width: 768px) {
      .container {
        padding: 1rem;
      }
      
      .logo {
        font-size: 2.5rem;
      }
      
      .tagline {
        font-size: 1.2rem;
      }
      
      .features {
        grid-template-columns: 1fr;
      }
    }
  `;

  private startApp() {
    this.showMainApp = true;
    this.dispatchEvent(new CustomEvent('start-app'));
  }

  private goBack() {
    // This could be used for navigation if we add more pages
    // For now, just a placeholder
    console.log('Back button clicked');
  }

  render() {
    if (this.showMainApp) {
      return html``;
    }

    return html`
      <div class="container">
        <div class="hero">
          <div class="logo"><gf-brand></gf-brand></div>
          <div class="tagline">Perform real‑time AI‑generated music with your MIDI controller</div>
          <div class="description">
             GrooveForge AI turns your controller into a live AI band. Blend genres, push dynamics, and perform evolving music on stage.
          </div>
          
           <button class="cta-button" @click=${this.startApp}>🚀 Enter</button>
        </div>

        <div class="features">
          <div class="feature">
            <div class="feature-icon">🎹</div>
            <div class="feature-title">MIDI Integration</div>
            <div class="feature-description">
              Use any MIDI controller to manipulate AI-generated music in real-time. 
              Control tempo, style, and musical elements with your hardware.
            </div>
          </div>
          
          <div class="feature">
            <div class="feature-icon">🤖</div>
            <div class="feature-title">AI-Powered Generation</div>
            <div class="feature-description">
              Leverage Google's Gemini AI to create unique musical compositions. 
              Generate new styles, instruments, and musical patterns on the fly.
            </div>
          </div>
          
          <div class="feature">
            <div class="feature-icon">⚡</div>
            <div class="feature-title">Real-Time Control</div>
            <div class="feature-description">
              Instantly adjust musical parameters and hear changes in real-time. 
              Perfect for live performances and experimental music creation.
            </div>
          </div>
        </div>

        <div class="tech-stack">
          <div class="tech-item">TypeScript</div>
          <div class="tech-item">Lit Framework</div>
          <div class="tech-item">Web MIDI API</div>
          <div class="tech-item">Google Gemini AI</div>
          <div class="tech-item">Web Audio API</div>
        </div>

        <div class="footer">
          <p>Built with modern web technologies for the future of music creation</p>
        </div>
      </div>
    `;
  }
}
