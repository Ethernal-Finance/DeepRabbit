/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { LitElement, html, css } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { getPricingForFirstSeen } from '../utils/pricing';
import { CHECKOUT_URL, STATUS_URL, VERIFY_URL, RETURN_URL, DEMO_ACCESS_CODE, CASHAPP_CASHTAG, CODE_ISSUER_URL } from '../utils/config';

@customElement('subscription-gate')
export class SubscriptionGate extends LitElement {
  static override styles = css`
    :host {
      display: block;
      min-height: 100vh;
      background: radial-gradient(1200px 600px at 20% 0%, rgba(0,255,136,0.08), transparent),
                  radial-gradient(1200px 600px at 80% 100%, rgba(0,255,136,0.08), transparent),
                  #0f0f0f;
      color: #e0e0e0;
      font-family: 'SF Mono', Monaco, 'Cascadia Code', 'Roboto Mono', Consolas, 'Courier New', monospace;
    }
    .wrap { max-width: 1000px; margin: 0 auto; padding: 40px 24px; }
    .header { display: flex; align-items: center; justify-content: space-between; }
    .brand { display: flex; align-items: center; gap: 14px; }
    .logo { width: 40px; height: 40px; }
    .title { font-size: 20px; font-weight: 900; letter-spacing: 1px; color: #00ff88; }
    .badge { font-size: 10px; background: #00ff88; color: #000; padding: 2px 6px; border-radius: 4px; font-weight: 900; margin-left: 6px; }
    .hero { margin: 64px 0 32px; display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 32px; align-items: center; }
    .headline { font-size: 36px; font-weight: 900; line-height: 1.15; }
    .sub { opacity: 0.8; margin-top: 12px; }
    .card { background: linear-gradient(135deg, #1a1a1a 0%, #0f0f0f 100%); border: 1px solid #2a2a2a; border-radius: 12px; padding: 20px; }
    .price { font-size: 28px; font-weight: 900; color: #00ff88; margin-bottom: 10px; }
    .cta { display: flex; flex-direction: column; gap: 10px; }
    .btn { background: linear-gradient(135deg, #00ff88 0%, #00cc6a 100%); color: #000; border: none; border-radius: 8px; padding: 12px 16px; font-weight: 800; letter-spacing: .5px; cursor: pointer; }
    .btn.secondary { background: #1a1a1a; border: 1px solid #333; color: #e0e0e0; }
    .btn.link { background: transparent; border: none; color: #00ff88; text-decoration: underline; padding: 0; }
    .demo { display:flex; gap:8px; margin-top:8px; }
    .demo input { flex:1; background: #111; border:1px solid #333; color:#e0e0e0; padding:8px 10px; border-radius:6px; }
    .note { font-size: 12px; color: #aaa; }
    .features { display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 16px; margin-top: 24px; }
    .feature { background: rgba(255,255,255,0.04); border: 1px solid #222; border-radius: 10px; padding: 14px; }
    .meta { opacity: 0.7; font-size: 12px; margin-top: 12px; }
    .status { margin-top: 18px; font-size: 12px; color: #aaa; }
    @media (max-width: 820px) { .hero { grid-template-columns: 1fr; } .features { grid-template-columns: 1fr; } }
  `;

  @state() private trialEndsAt: number | null = null; // legacy, not used for gating
  @state() private subscribed = false;
  @state() private priceUsd = 9.99;
  @state() private priceLabel = 'Standard';

  private readonly LS_TRIAL = 'grooveforge_trial_expiry';
  private readonly LS_SUB = 'grooveforge_subscribed';

  override connectedCallback() {
    super.connectedCallback();
    const t = localStorage.getItem(this.LS_TRIAL);
    this.trialEndsAt = t ? Number(t) : null;
    this.subscribed = localStorage.getItem(this.LS_SUB) === '1';
    // cohorting
    const LS_FIRST_SEEN = 'gf_first_seen';
    let firstSeen = localStorage.getItem(LS_FIRST_SEEN);
    if (!firstSeen) {
      firstSeen = String(Date.now());
      localStorage.setItem(LS_FIRST_SEEN, firstSeen);
    }
    const pricing = getPricingForFirstSeen(Number(firstSeen));
    this.priceUsd = pricing.priceMonthlyUsd;
    this.priceLabel = pricing.label;
    if (this.isAllowed()) {
      // Auto-advance if already allowed
      queueMicrotask(() => this.enterApp());
    }
  }

  private isAllowed(): boolean {
    return this.subscribed === true;
  }

  private async checkStatusByEmail(email: string) {
    if (!STATUS_URL) return null;
    try {
      const res = await fetch(`${STATUS_URL}?email=${encodeURIComponent(email)}`, { credentials: 'include' });
      if (!res.ok) return null;
      const json = await res.json();
      return json?.active === true ? json : null;
    } catch { return null; }
  }

  private async verifyToken(token: string) {
    if (!VERIFY_URL) return false;
    try {
      const res = await fetch(`${VERIFY_URL}?token=${encodeURIComponent(token)}`, { credentials: 'include' });
      if (!res.ok) return false;
      const json = await res.json();
      return json?.verified === true;
    } catch { return false; }
  }

  private goToCheckout() {
    // Prefer Cash App one-time payment if configured, else fallback to generic checkout URL
    if (CASHAPP_CASHTAG) {
      const u = new URL('https://cash.app/$' + CASHAPP_CASHTAG);
      // Cash App supports optional amount param
      u.searchParams.set('amount', '5');
      window.open(u.toString(), '_blank');
      alert('After paying $5 on Cash App, enter your email below to receive your access code.');
      return;
    }
    const url = CHECKOUT_URL;
    if (!url) return window.alert('Checkout is not configured.');
    const r = RETURN_URL || window.location.origin;
    const u = new URL(url);
    u.searchParams.set('return_url', r);
    window.open(u.toString(), '_blank');
  }

  private async requestAccessCode() {
    if (!CODE_ISSUER_URL) return alert('Code issuer not configured.');
    const email = prompt('Enter your email for the access code:');
    if (!email) return;
    try {
      const res = await fetch(CODE_ISSUER_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error('Failed to request code');
      alert('If your payment was received, a code will be emailed to you shortly.');
    } catch (e: any) {
      alert(e.message || 'Failed to request code');
    }
  }

  private daysLeft(): number {
    if (!this.trialEndsAt) return 0;
    const ms = Math.max(0, this.trialEndsAt - Date.now());
    return Math.ceil(ms / (24 * 60 * 60 * 1000));
  }

  private startTrial() { this.enterApp(); }

  private markSubscribed() {
    localStorage.setItem(this.LS_SUB, '1');
    this.subscribed = true;
    this.requestUpdate();
    this.enterApp();
  }

  private enterApp() {
    this.dispatchEvent(new CustomEvent('enter-app'));
  }

  private getLogo() {
    // Simple forged G mark
    return html`
      <svg class="logo" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="GrooveForge AI">
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#00ff88"/>
            <stop offset="100%" stop-color="#00cc6a"/>
          </linearGradient>
        </defs>
        <rect x="4" y="4" width="56" height="56" rx="12" fill="#111" stroke="url(#g)" stroke-width="3"/>
        <path d="M20,32c0,-8 6,-14 14,-14c8,0 14,6 14,14c0,8 -6,14 -14,14h-2v-10h10" fill="none" stroke="url(#g)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `;
  }

  override render() {
    const allowed = this.isAllowed();
    const trialActive = !this.subscribed && this.trialEndsAt && Date.now() < this.trialEndsAt;
    return html`
      <div class="wrap">
        <div class="header">
          <div class="brand">
            ${this.getLogo()}
            <div class="title">GrooveForge AI<span class="badge">PRO</span></div>
          </div>
        </div>

        <div class="hero">
          <div>
            <div class="headline">Real‑time AI music you can perform. Shape sound with words and MIDI.</div>
            <div class="sub">GrooveForge AI turns your controller into a live AI band. Blend genres, push dynamics, and perform evolving music on stage.</div>

            <div class="features">
              <div class="feature">🎛️ MIDI‑learn any control in seconds</div>
              <div class="feature">⚡ Low‑latency live audio streaming</div>
              <div class="feature">🎚️ Up to 8 active prompt slots with a deep style library</div>
              <div class="feature">🎶 Instrument layers and genre morphing</div>
              <div class="feature">🔒 Offline-safe session fallback</div>
              <div class="feature">💡 Setlists and one‑tap recall (coming soon)</div>
            </div>
          </div>

          <div class="card">
            <div class="price">$5 one‑time <span class="meta">· Lifetime access</span></div>
            <div class="meta">Pay once, receive an access code via email, and enjoy lifetime use.</div>
            <div class="cta">
              ${allowed ? html`
                <button class="btn" @click=${this.enterApp}>Continue</button>
                <div class="status">Lifetime access active</div>
              ` : html`
                <button class="btn secondary" @click=${this.goToCheckout}>One‑time $5 (Cash App)</button>
                <button class="btn link" @click=${this.requestAccessCode}>Email me an access code</button>
                <button class="btn link" @click=${async () => {
                  const email = prompt('Enter your subscription email to verify access:');
                  if (!email) return;
                  const resp = await this.checkStatusByEmail(email);
                  if (resp) { this.markSubscribed(); } else { alert('No active subscription found.'); }
                }}>I already paid</button>
                <div class="demo">
                  <input id="demo-code" type="text" placeholder="Enter access code" />
                  <button class="btn secondary" @click=${async () => {
                    const input = this.renderRoot?.querySelector('#demo-code') as HTMLInputElement | null;
                    if (!input) return;
                    const code = input.value.trim();
                    if (!code) return alert('Enter a code');
                    if (VERIFY_URL) {
                      const ok = await this.verifyToken(code);
                      if (ok) { this.markSubscribed(); return; }
                    }
                    if (DEMO_ACCESS_CODE && code === DEMO_ACCESS_CODE) {
                      this.markSubscribed();
                    } else {
                      alert('Invalid access code');
                    }
                  }}>Verify Code</button>
                </div>
                <div class="note">We’ll send a random access code to your email once payment is received.</div>
              `}
            </div>
          </div>
        </div>
      </div>
    `;
  }
}

declare global {
  interface HTMLElementTagNameMap {
    'subscription-gate': SubscriptionGate;
  }
}


